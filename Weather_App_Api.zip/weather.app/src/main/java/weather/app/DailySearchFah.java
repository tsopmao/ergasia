package weather.app;

import java.util.Date;

import weather.api.client.CityNames;
import weather.api.client.Daily;
import weather.api.client.Units;
import weather.api.service.WeatherService;

public class DailySearchFah {

	public static void main(String[] args) {

		WeatherMenu.weather.nextLine();
		System.out.print("Επιλέξτε πόλη ή συνδυασμό πόλης,χώρας: ");
		String CityName = WeatherMenu.weather.nextLine().replaceAll("\\s+", "");
		while (CityName.isBlank()) {
			System.out.print("Επιλέξτε πόλη ή συνδυασμό πόλης,χώρας: ");
			CityName = WeatherMenu.weather.nextLine().replaceAll("\\s+", "");
		}
		try {
			CityNames city = WeatherService.getCityNamesLatLonCheck(CityName);
			Daily dayweather = WeatherService.getDailyWeatherInfoCheck(String.valueOf(city.getLat()),
					String.valueOf(city.getLon()), Units.FAHRENHEIT);
			System.out.println("\nlat=" + dayweather.getLat() + "\nlon=" + dayweather.getLon() + "\ntimezone="
					+ dayweather.getTimezone());
			for (int i = 0; i <= 4; i++) {
				Date dtDate = new Date(dayweather.getDaily().get(i).getDt() * 1000);
				System.out.println("\n\n" + dtDate + dayweather.getDaily().get(i));
			}
		} catch (Exception e) {
			System.out.println("\nΑυτή η πόλη ή ο συνδυασμός πόλης,χώρας δεν υπάρχουν. Δοκιμάστε ξανά");
		}
	}
}
