package weather.app;

import java.util.Date;

import weather.api.client.Current;
import weather.api.client.Units;
import weather.api.service.WeatherService;

public class CurrentIpCel {

	public static void main(String[] args) {

		try {
			Current curweather = WeatherService.getCurrentWeatherInfo(Units.CELSIUS);
			Date dtDate = new Date(curweather.getCurrent().getDt() * 1000);
			System.out.println("\nlat=" + curweather.getLat() + "\nlon=" + curweather.getLon() + "\ntimezone="
					+ curweather.getTimezone() + "\n\n" + dtDate + curweather.getCurrent());
		} catch (Exception e) {
			System.out.println("\nΚάτι πήγε στραβά. Δοκιμάστε ξανά");
		}
	}
}
