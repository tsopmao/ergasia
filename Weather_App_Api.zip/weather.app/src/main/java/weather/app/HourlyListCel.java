package weather.app;

import weather.api.client.CityNames;
import weather.api.client.Hourly;
import weather.api.client.Units;
import weather.api.service.WeatherService;

public class HourlyListCel {

	public static void main(String[] args) {

		if (WeatherMenu.cityList.size() == 0) {
			System.out.println("Η λίστα σας έιναι άδεια, προσθέστε πόλεις και δοκιμάστε ξανά");
		} else {
			int Choice = -1;
			System.out.println(
					"Επιλέξτε μια πόλη από την παρακάτω λίστα, με αριθμούς που αντιστοιχούν σε κάθε πόλη, αρχίζοντας από το 0\n"
							+ WeatherMenu.cityList + "\n");

			try {
				while (!WeatherMenu.weather.hasNextInt()) {
					WeatherMenu.weather.next();
					System.out.println("Εισάγετε αριθμό");
				}
				Choice = WeatherMenu.weather.nextInt();
				while (Choice >= WeatherMenu.cityList.size() || Choice < 0)
					if (WeatherMenu.weather.hasNextInt())
						Choice = WeatherMenu.weather.nextInt();
					else {
						WeatherMenu.weather.next();
						System.out.println("Εισάγετε αριθμό");
					}

				CityNames city = WeatherService.getCityNamesLatLonCheck(WeatherMenu.cityList.get(Choice));
				Hourly hourweather = WeatherService.getHourlyWeatherInfoCheck(String.valueOf(city.getLat()),
						String.valueOf(city.getLon()), Units.CELSIUS);
				System.out.println("\nlat=" + hourweather.getLat() + "\nlon=" + hourweather.getLot() + "\ntimezone="
						+ hourweather.getTimezone());
				for (int i = 0; i <= 47; i++) {
					System.out.println(hourweather.getHourly().get(i));
				}
			} catch (Exception e) {
				System.out.println("\nΑυτή η πόλη ή ο συνδυασμός πόλης,χώρας δεν υπάρχουν. Δοκιμάστε άλλη πόλη");
			}
		}
	}
}
