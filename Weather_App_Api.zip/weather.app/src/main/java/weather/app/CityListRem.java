package weather.app;

public class CityListRem {

	public static void main(String[] args) {

		if (WeatherMenu.cityList.size() == 0) {
			System.out.println("Η λίστα σας έιναι άδεια");
		} else {
			int Choice = -1;
			System.out.println(
					"Επιλέξτε μια πόλη προς αφαίρεση από την παρακάτω λίστα, με αριθμούς που αντιστοιχούν σε κάθε πόλη, αρχίζοντας από το 0\n"
							+ WeatherMenu.cityList + "\n");
			try {
				while (!WeatherMenu.weather.hasNextInt()) {
					WeatherMenu.weather.next();
					System.out.println("Εισάγετε αριθμό");
				}
				Choice = WeatherMenu.weather.nextInt();
				while (Choice >= WeatherMenu.cityList.size() || Choice < 0)
					if (WeatherMenu.weather.hasNextInt())
						Choice = WeatherMenu.weather.nextInt();
					else {
						WeatherMenu.weather.next();
						System.out.println("Εισάγετε αριθμό");
					}

				System.out.println("\nΗ πόλη '" + WeatherMenu.cityList.get(Choice) + "' αφαιρέθηκε με επιτυχία");
				WeatherMenu.cityList.remove(Choice);
			} catch (Exception e) {
				System.out.println("\nΑυτή η επιλογή δεν υπάρχει. Δοκιμάστε άλλη πόλη");
			}
		}
	}
}
