package weather.app;

import java.util.Date;

import weather.api.client.CityNames;
import weather.api.client.Current;
import weather.api.client.Units;
import weather.api.service.WeatherService;

public class CurrentListFah {

	public static void main(String[] args) {

		if (WeatherMenu.cityList.size() == 0) {
			System.out.println("Η λίστα σας έιναι άδεια, προσθέστε πόλεις και δοκιμάστε ξανά");
		} else {
			int Choice = -1;
			System.out.println(
					"Επιλέξτε μια πόλη από την παρακάτω λίστα, με αριθμούς που αντιστοιχούν σε κάθε πόλη, αρχίζοντας από το 0\n"
							+ WeatherMenu.cityList + "\n");

			try {
				while (!WeatherMenu.weather.hasNextInt()) {
					WeatherMenu.weather.next();
					System.out.println("Εισάγετε αριθμό");
				}
				Choice = WeatherMenu.weather.nextInt();
				while (Choice >= WeatherMenu.cityList.size() || Choice < 0)
					if (WeatherMenu.weather.hasNextInt())
						Choice = WeatherMenu.weather.nextInt();
					else {
						WeatherMenu.weather.next();
						System.out.println("Εισάγετε αριθμό");
					}

				CityNames city = WeatherService.getCityNamesLatLonCheck(WeatherMenu.cityList.get(Choice));
				Current curweather = WeatherService.getCurrentWeatherInfoCheck(String.valueOf(city.getLat()),
						String.valueOf(city.getLon()), Units.FAHRENHEIT);
				Date dtDate = new Date(curweather.getCurrent().getDt() * 1000);
				System.out.println("\nlat=" + curweather.getLat() + "\nlon=" + curweather.getLon() + "\ntimezone="
						+ curweather.getTimezone() + "\n\n" + dtDate + curweather.getCurrent());
			} catch (Exception e) {
				System.out.println("\nΑυτή η πόλη ή ο συνδυασμός πόλης,χώρας δεν υπάρχουν. Δοκιμάστε άλλη πόλη");
			}
		}
	}
}
