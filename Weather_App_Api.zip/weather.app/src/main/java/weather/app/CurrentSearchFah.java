package weather.app;

import java.util.Date;

import weather.api.client.CityNames;
import weather.api.client.Current;
import weather.api.client.Units;
import weather.api.service.WeatherService;

public class CurrentSearchFah {

	public static void main(String[] args) {

		WeatherMenu.weather.nextLine();
		System.out.print("Επιλέξτε πόλη ή συνδυασμό πόλης,χώρας: ");
		String CityName = WeatherMenu.weather.nextLine().replaceAll("\\s+", "");
		while (CityName.isBlank()) {
			System.out.print("Επιλέξτε πόλη ή συνδυασμό πόλης,χώρας: ");
			CityName = WeatherMenu.weather.nextLine().replaceAll("\\s+", "");
		}
		try {
			CityNames city = WeatherService.getCityNamesLatLonCheck(CityName);
			Current curweather = WeatherService.getCurrentWeatherInfoCheck(String.valueOf(city.getLat()),
					String.valueOf(city.getLon()), Units.FAHRENHEIT);
			Date dtDate = new Date(curweather.getCurrent().getDt() * 1000);
			System.out.println("\nlat=" + curweather.getLat() + "\nlon=" + curweather.getLon() + "\ntimezone="
					+ curweather.getTimezone() + "\n\n" + dtDate + curweather.getCurrent());
		} catch (Exception e) {
			System.out.println("\nΑυτή η πόλη ή ο συνδυασμός πόλης,χώρας δεν υπάρχουν. Δοκιμάστε ξανά");
		}
	}
}
