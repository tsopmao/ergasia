package weather.app;

import java.util.ArrayList;
import java.util.Scanner;

public class WeatherMenu {

	public static final Scanner weather=new Scanner(System.in);
	static ArrayList<String> cityList = new ArrayList<>();
	
	public static void main(String[] args) {
		
		System.out.println("\nWelcome to the Weather App\n\nΔείτε τον καιρό πληκτρολογώντας το όνομα της πόλης και τον κωδικό της χώρας στην οποία ανήκει,"
				+ " για παράδειγμα: 'Athens,GR'\nή επιλέγοντας από τις πόλεις που έχετε αποθηκεύσει στην λίστα.\n");
        int choice=-1;
        MainMenu();
        while (!weather.hasNextInt()) weather.next();
        choice=weather.nextInt();
        while(choice!=3) {
            switch (choice) {
            case 1:
                System.out.println("ΔΕΛΤΙΟ ΚΑΙΡΟΥ");
                WeathMenu();
                while (!weather.hasNextInt()) weather.next();
                choice=weather.nextInt();
                while(choice!=4) {
                    switch (choice) {
                    case 1:
                    	
                    	System.out.println("ΕΠΙΛΟΓΗ ΠΟΛΗΣ");
                        IpMenu();
                        while (!weather.hasNextInt()) weather.next();
                        choice=weather.nextInt();
                        while(choice!=4) {
                            switch (choice) {
                            case 1:
                            	System.out.println("ΕΠΙΛΟΓΗ ΜΟΝΑΔΑΣ ΘΕΡΜΟΚΡΑΣΙΑΣ");
                                TempMenu();
                                while (!weather.hasNextInt()) weather.next();
                                choice=weather.nextInt();
                                while(choice!=3) {
                                    switch (choice) {
                                    case 1:
                                    	CurrentIpCel.main(args);
                                    	break;
                                    case 2:
                                    	CurrentIpFah.main(args);
                                    	break;	
                                    }
                                    TempMenu();
                                    while (!weather.hasNextInt()) weather.next();
                                    choice=weather.nextInt(); 
                                }
                            	break;
                            case 2:
                            	System.out.println("ΕΠΙΛΟΓΗ ΜΟΝΑΔΑΣ ΘΕΡΜΟΚΡΑΣΙΑΣ");
                                TempMenu();
                                while (!weather.hasNextInt()) weather.next();
                                choice=weather.nextInt();
                                while(choice!=3) {
                                    switch (choice) {
                                    case 1:
                                    	CurrentListCel.main(args);
                                    	break;
                                    case 2:
                                    	CurrentListFah.main(args);
                                    	break;	
                                    }
                                    TempMenu();
                                    while (!weather.hasNextInt()) weather.next();
                                    choice=weather.nextInt(); 
                                }
                            	break;	
                            case 3:
                            	System.out.println("ΕΠΙΛΟΓΗ ΜΟΝΑΔΑΣ ΘΕΡΜΟΚΡΑΣΙΑΣ");
                                TempMenu();
                                while (!weather.hasNextInt()) weather.next();
                                choice=weather.nextInt();
                                while(choice!=3) {
                                    switch (choice) {
                                    case 1:
                                    	CurrentSearchCel.main(args);
                                    	break;
                                    case 2:
                                    	CurrentSearchFah.main(args);
                                    	break;	
                                    }
                                    TempMenu();
                                    while (!weather.hasNextInt()) weather.next();
                                    choice=weather.nextInt(); 
                                }
                            	break;
                            }
                            IpMenu();
                            while (!weather.hasNextInt()) weather.next();
                            choice=weather.nextInt(); 
                        }
                    	
                    	break;	
                    case 2:
                    	
                    	System.out.println("ΕΠΙΛΟΓΗ ΠΟΛΗΣ");
                        CityMenu();
                        while (!weather.hasNextInt()) weather.next();
                        choice=weather.nextInt();
                        while(choice!=3) {
                            switch (choice) {
                            case 1:
                            	System.out.println("ΕΠΙΛΟΓΗ ΜΟΝΑΔΑΣ ΘΕΡΜΟΚΡΑΣΙΑΣ");
                                TempMenu();
                                while (!weather.hasNextInt()) weather.next();
                                choice=weather.nextInt();
                                while(choice!=3) {
                                    switch (choice) {
                                    case 1:
                                    	HourlyListCel.main(args);
                                    	break;
                                    case 2:
                                    	HourlyListFah.main(args);
                                    	break;	
                                    }
                                    TempMenu();
                                    while (!weather.hasNextInt()) weather.next();
                                    choice=weather.nextInt(); 
                                }
                            	break;
                            case 2:
                            	System.out.println("ΕΠΙΛΟΓΗ ΜΟΝΑΔΑΣ ΘΕΡΜΟΚΡΑΣΙΑΣ");
                                TempMenu();
                                while (!weather.hasNextInt()) weather.next();
                                choice=weather.nextInt();
                                while(choice!=3) {
                                    switch (choice) {
                                    case 1:
                                    	HourlySearchCel.main(args);
                                    	break;
                                    case 2:
                                    	HourlySearchFah.main(args);
                                    	break;	
                                    }
                                    TempMenu();
                                    while (!weather.hasNextInt()) weather.next();
                                    choice=weather.nextInt(); 
                                }
                            	break;	
                          
                            }
                            CityMenu();
                            while (!weather.hasNextInt()) weather.next();
                            choice=weather.nextInt(); 
                        }
                    	
                    	break;	
                    case 3:
                    	
                    	System.out.println("ΕΠΙΛΟΓΗ ΠΟΛΗΣ");
                        CityMenu();
                        while (!weather.hasNextInt()) weather.next();
                        choice=weather.nextInt();
                        while(choice!=3) {
                            switch (choice) {
                            case 1:
                            	System.out.println("ΕΠΙΛΟΓΗ ΜΟΝΑΔΑΣ ΘΕΡΜΟΚΡΑΣΙΑΣ");
                                TempMenu();
                                while (!weather.hasNextInt()) weather.next();
                                choice=weather.nextInt();
                                while(choice!=3) {
                                    switch (choice) {
                                    case 1:
                                    	DailyListCel.main(args);
                                    	break;
                                    case 2:
                                    	DailyListFah.main(args);
                                    	break;	
                                    }
                                    TempMenu();
                                    while (!weather.hasNextInt()) weather.next();
                                    choice=weather.nextInt(); 
                                }
                            	break;
                            case 2:
                            	System.out.println("ΕΠΙΛΟΓΗ ΜΟΝΑΔΑΣ ΘΕΡΜΟΚΡΑΣΙΑΣ");
                                TempMenu();
                                while (!weather.hasNextInt()) weather.next();
                                choice=weather.nextInt();
                                while(choice!=3) {
                                    switch (choice) {
                                    case 1:
                                    	DailySearchCel.main(args);
                                    	break;
                                    case 2:
                                    	DailySearchFah.main(args);
                                    	break;	
                                    }
                                    TempMenu();
                                    while (!weather.hasNextInt()) weather.next();
                                    choice=weather.nextInt(); 
                                }
                            	break;	
                          
                            }
                            CityMenu();
                            while (!weather.hasNextInt()) weather.next();
                            choice=weather.nextInt(); 
                        }
                    	
                    	break;
                    }
                    WeathMenu();
                    while (!weather.hasNextInt()) weather.next();
                    choice=weather.nextInt(); 
                }
                break;
                    
            case 2:
                System.out.println("ΔΙΑΧΕΙΡΙΣΗ ΠΟΛΕΩΝ");
                CityDetMenu();
                while (!weather.hasNextInt()) weather.next();
                choice=weather.nextInt();
                while(choice!=3) {
                    switch (choice) {
                    case 1:
                    	CityListAdd.main(args);
                    	break;
                    case 2:
                    	CityListRem.main(args);
                    	break;	
                    }
                    CityDetMenu();
                    while (!weather.hasNextInt()) weather.next();
                    choice=weather.nextInt(); 
                }
                break;
                
            }
            MainMenu();
            while (!weather.hasNextInt()) weather.next();
            choice=weather.nextInt();
        }
        weather.close();
    System.out.println("SEE YA\nΕΥΘΥΜΙΟΣ ΟΡΦΑΝΙΔΗΣ and ΘΩΜΑΣ ΤΣΟΠΕΛΑΣ");
    }

    public static void MainMenu() {
        System.out.println("Choose an action:\n"
                + "1) Δελτίο Καιρού\n"
                + "2) Διαχείρηση Πόλεων\n"
                + "3) EXIT\n"
                );
    }
    
    public static void WeathMenu() {
        System.out.println("\nChoose an action:\n"
                + "1) Τρέχουσες Καιρικές Συνθήκες\n"
                + "2) Ωριαία Πρόγνωση Καιρού\n"
                + "3) Ημερήσια Πρόγνωση Καιρού (5ήμερη)\n"
                + "4) MAIN MENU\n"
                );	
    }
    
    public static void IpMenu() {
        System.out.println("\nChoose an action:\n"
                + "1) Τρέχουσα Τοποθεσία\n"
                + "2) Από Λίστα\n"
                + "3) Αναζήτηση Πόλης\n"
                + "4) BACK\n"
                );	
    }
    
    public static void CityMenu() {
        System.out.println("\nChoose an action:\n"
                + "1) Από Λίστα\n"
                + "2) Αναζήτηση Πόλης\n"
                + "3) BACK\n"
                );	
    }
    
    public static void CityDetMenu() {
        System.out.println("\nChoose an action:\n"
                + "1) Προσθήκη Νέας Πόλης\n"
                + "2) Διαγραφή Πόλης\n"
                + "3) MAIN MENU\n"
                );	
    }
    
    public static void TempMenu() {
        System.out.println("\nChoose an action:\n"
                + "1) Celsius\n"
                + "2) Fahrenheit\n"
                + "3) BACK\n"
                );	
    }
        
}