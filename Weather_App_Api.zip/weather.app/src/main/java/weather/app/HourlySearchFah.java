package weather.app;

import weather.api.client.CityNames;
import weather.api.client.Hourly;
import weather.api.client.Units;
import weather.api.service.WeatherService;

public class HourlySearchFah {

	public static void main(String[] args) {

		WeatherMenu.weather.nextLine();
		System.out.print("Επιλέξτε πόλη ή συνδυασμό πόλης,χώρας: ");
		String CityName = WeatherMenu.weather.nextLine().replaceAll("\\s+", "");
		while (CityName.isBlank()) {
			System.out.print("Επιλέξτε πόλη ή συνδυασμό πόλης,χώρας: ");
			CityName = WeatherMenu.weather.nextLine().replaceAll("\\s+", "");
		}
		try {
			CityNames city = WeatherService.getCityNamesLatLonCheck(CityName);
			Hourly hourweather = WeatherService.getHourlyWeatherInfoCheck(String.valueOf(city.getLat()),
					String.valueOf(city.getLon()), Units.FAHRENHEIT);
			System.out.println("\nlat=" + hourweather.getLat() + "\nlon=" + hourweather.getLot() + "\ntimezone="
					+ hourweather.getTimezone());
			for (int i = 0; i <= 47; i++) {
				System.out.println(hourweather.getHourly().get(i));
			}
		} catch (Exception e) {
			System.out.println("\nΑυτή η πόλη ή ο συνδυασμός πόλης,χώρας δεν υπάρχουν. Δοκιμάστε ξανά");
		}
	}
}
