package weather.app;

public class CityListAdd {

	public static void main(String[] args) {

		WeatherMenu.weather.nextLine();
		System.out.println("Πληκτρολογήστε την πόλη ή τον συνδυασμό πόλης,χώρας που θέλετε να εισάγετε στην λίστα\n");
		String city = WeatherMenu.weather.nextLine().replaceAll("\\s+", "");
		if (city.matches("^[a-zA-Z,]*$")) {
			try {
				WeatherMenu.cityList.add(city);
				System.out.println("\nΗ πόλη προστέθηκε με επιτυχία\n" + WeatherMenu.cityList);
			} catch (Exception e) {
				System.out.println(
						"\nΑυτή η πόλη ή ο συνδυασμός πόλης,χώρας δεν μπορούν να εισαχθούν. Δοκιμάστε άλλη πόλη");
			}
		} else {
			System.out.println("\nΠρέπει να εισάγετε μόνο χαρακτήρες. Δοκιμάστε ξανά");
		}
	}
}
