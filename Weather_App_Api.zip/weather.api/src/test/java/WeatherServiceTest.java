import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import weather.api.client.CityNames;
import weather.api.client.Current;
import weather.api.client.Hourly;
import weather.api.client.Units;
import weather.api.exceptions.Internal;
import weather.api.exceptions.InvalidArgument;
import weather.api.service.WeatherService;

public class WeatherServiceTest {

	@Test
	public void getHourlyWeatherInfoTest() throws Exception {
		Hourly hourlyWeatherInfo = WeatherService.getHourlyWeatherInfoCheck("37.983810", "23.727539", Units.CELSIUS);
		Assertions.assertNotNull(hourlyWeatherInfo);
		Assertions.assertEquals(hourlyWeatherInfo.getHourly().size(), 48);
	}

	@Test
	public void getHourlyWeatherInfoWrongInputTest() {
		InvalidArgument invalidArgumentException = Assertions.assertThrows(InvalidArgument.class, () -> { // Lambda Expression
																											
			WeatherService.getHourlyWeatherInfoCheck(null, "23.727539", null);
		});
		Assertions.assertNotNull(invalidArgumentException.getMessage());
	}

	@Test
	public void getHourlyWeatherInfoErrorLatTest() {
		Internal internalException = Assertions.assertThrows(Internal.class, () -> { 
			WeatherService.getHourlyWeatherInfoCheck("23fsdcvs", "23.727539", Units.CELSIUS);
		});
		Assertions.assertNotNull(internalException.getMessage());
	}

	@Test
	public void testGetCurrentWeatherInfoFromIP() throws Internal {
		Current currentWeatherInfo = WeatherService.getCurrentWeatherInfo(Units.CELSIUS);
		Assertions.assertNotNull(currentWeatherInfo);
	}

	@Test
	public void getCityNamesInfoTest() throws Exception {
		CityNames cityNamesInfo = WeatherService.getCityNamesLatLonCheck("Athens");
		Assertions.assertNotNull(cityNamesInfo);
		Assertions.assertEquals(cityNamesInfo.getLat(),String.valueOf(37.9795));
	}
	
	@Test
	public void getCityNamesInfoErrorTest() throws Internal {
		Internal internalException = Assertions.assertThrows(Internal.class, () -> {
			WeatherService.getCityNamesLatLonCheck("lalala");
		});
		Assertions.assertNotNull(internalException.getMessage());
	}
}
