package weather.api.service;

import weather.api.client.CityNames;
import weather.api.client.Current;
import weather.api.client.Daily;
import weather.api.client.Hourly;
import weather.api.client.Units;

public class TestMain {

	public static void main(String[] args) throws Exception {
	
		Hourly test = WeatherService.getHourlyWeatherInfoCheck("37.983810", "23.727539", Units.CELSIUS);
        System.out.println(test.getTimezone());
        System.out.println(test.getHourly());
        
        Daily test2 = WeatherService.getDailyWeatherInfoCheck("51.5074", "0.1278", Units.CELSIUS);
        System.out.println(test2.getTimezone());
        System.out.println(test2.getDaily());
        
        Current test3 = WeatherService.getCurrentWeatherInfoCheck("37.983810", "23.727539", Units.CELSIUS);
        System.out.println(test3.getTimezone());
        
        Current test4 = WeatherService.getCurrentWeatherInfo(Units.CELSIUS);
        System.out.println(test4.getTimezone());
        
        CityNames test5 = WeatherService.getCityNamesLatLonCheck("Athens");
        System.out.println(test5.getLat());
        System.out.println(test5.getLon());
        
        Daily test6 = WeatherService.getDailyWeatherInfoCheck(String.valueOf(test5.getLat()),String.valueOf(test5.getLon()), Units.CELSIUS);
        System.out.println(test6.getDaily());
	}
}
