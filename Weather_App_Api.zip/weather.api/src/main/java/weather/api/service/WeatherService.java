package weather.api.service;

import weather.api.client.CityNames;
import weather.api.client.Current;
import weather.api.client.Daily;
import weather.api.client.Hourly;
import weather.api.client.LatLon;
import weather.api.client.Units;
import weather.api.client.WeatherApiCall;
import weather.api.exceptions.Internal;
import weather.api.exceptions.InvalidArgument;

public class WeatherService {

	public static Hourly getHourlyWeatherInfoCheck(String latitude, String longitude, Units metricUnit)
			throws InvalidArgument, Internal {
		// Τσεκάρουμε για null και no length String σε όλα τα parameters
		if (isNullOrEmpty(latitude) || isNullOrEmpty(longitude) || metricUnit == null) {
			throw new InvalidArgument("Λάθος παράμετροι");
		}
		// Επιστρέφει τις τιμές της μεθόδου
		return WeatherApiCall.getHourlyWeatherInfo(latitude, longitude, metricUnit);
	}

	
	public static Daily getDailyWeatherInfoCheck(String latitude, String longitude, Units metricUnit)
			throws InvalidArgument, Internal {
		// Τσεκάρουμε για null και no length String σε όλα τα parameters
		if (isNullOrEmpty(latitude) || isNullOrEmpty(longitude) || metricUnit == null) {
			throw new InvalidArgument("Λάθος παράμετροι");
		}
		return WeatherApiCall.getDailyWeatherInfo(latitude, longitude, metricUnit);
	}

	
	public static Current getCurrentWeatherInfoCheck(String latitude, String longitude, Units metricUnit)
			throws InvalidArgument, Internal {
		// Τσεκάρουμε για null και no length String σε όλα τα parameters
		if (isNullOrEmpty(latitude) || isNullOrEmpty(longitude) || metricUnit == null) {
			throw new InvalidArgument("Λάθος παράμετροι");
		}
		return WeatherApiCall.getCurrentWeatherInfo(latitude, longitude, metricUnit);
	}

	
	public static Current getCurrentWeatherInfo(Units metricUnit) throws Internal {
		LatLon geolocationInfo = WeatherApiCall.getGeolocationInfo();
		return WeatherApiCall.getCurrentWeatherInfo(String.valueOf(geolocationInfo.getLatitude()),
				String.valueOf(geolocationInfo.getLongitude()), metricUnit);
	}

	
	public static CityNames getCityNamesLatLonCheck(String citycountry) throws InvalidArgument, Internal {
		// Τσεκάρουμε για null και no length String σε όλα τα parameters
		if (isNullOrEmpty(citycountry)) {
			throw new InvalidArgument("Λάθος παράμετροι");
		}
		// Επιστρέφει τις τιμές της μεθόδου
		return WeatherApiCall.getCityNamesLatLon(citycountry);
	}

	
	public static boolean isNullOrEmpty(String stringToCheck) {
		// το κάνουμε null-safe
		return stringToCheck == null || stringToCheck.isEmpty();
	}
}
