package weather.api.exceptions;

public class Internal extends Exception {
	
	private static final long serialVersionUID = 1L;

	public Internal(String message) {
        super(message);
    }

    public Internal(String message, Throwable cause) {
        super(message, cause);
    }
}