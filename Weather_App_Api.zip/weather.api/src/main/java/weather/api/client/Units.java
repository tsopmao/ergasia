package weather.api.client;

public enum Units {

    CELSIUS("metric","celsius"),
    FAHRENHEIT("imperial","fahrenheit");

    Units(String key, String description) {
        this.key = key;
        this.description = description;
    }

    
    private String key;
    private String description;

    public String getKey() {
        return key;
    }

    public String getDescription() {
        return description;
    }
}
