package weather.api.client;

public class Current {

    private String lat;
    private String lon;
    private String timezone;
    private CurrentDet current;

    
    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {  //constructor με παράμετρο
        this.lat = lat;
    }

    public String getLon() {
        return lon;
    }

    public void setLon(String lon) {  //constructor με παράμετρο
        this.lon = lon;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {  //constructor με παράμετρο
        this.timezone = timezone;
    }

    public CurrentDet getCurrent() {
        return current;
    }

    public void setCurrent(CurrentDet current) {  //constructor με παράμετρο
        this.current = current;
    }

	@Override
	public String toString() {
		return "\nlat=" + lat + "\nlon=" + lon + "\ntimezone=" + timezone + "\n" + current;
	}
}
