package weather.api.client;

import java.util.List;

public class HourlyDet {

    private float temp;
    private List<Weather> weather;


    public float getTemp() {
        return temp;
    }

    public void setTemp(float temp) {
        this.temp = temp;
    }

    public List<Weather> getWeather() {
        return weather;
    }

    public void setWeather(List<Weather> weather) {
        this.weather = weather;
    }

	@Override
	public String toString() {
		return "\ntemp=" + temp + "\nweather=" + weather;
	}
}
