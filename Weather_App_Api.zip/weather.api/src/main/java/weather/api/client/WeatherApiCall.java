package weather.api.client;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import weather.api.exceptions.Internal;

public class WeatherApiCall {

	//το URL για το One Call API
    private static final String WEATHER_API_URI = "https://api.openweathermap.org/data/2.5/onecall";
    //τα στοιχεία που δεν θέλουμε να επιστρέψουν από το API response
    private static final String INITIAL_EXCLUDED_CATEGORIES = "minutely,alerts";
    //το κλειδί του API
    private static final String API_KEY = "8c3c4df733f5dbedb4e5ae105dde6005";
    
    //το URL για το Geocoding API
    private static final String CITYNAMES_API_URI = "http://api.openweathermap.org/geo/1.0/direct?";
    
    //το κλειδί του API για την εύρεση του location του χρήστη μέσω ip address
    private static final String GEO_API_KEY = "4f767cca144486a01e84e25bdb177e4e";

 
    public static Hourly getHourlyWeatherInfo(String latitude, String longitude, Units metricUnit) throws Internal {
        try {
            String excludedCategories = INITIAL_EXCLUDED_CATEGORIES + "," + "daily" + "," + "current";
            String json = callWeatherApi(latitude, longitude, metricUnit, excludedCategories);
          //δημιουργούμε νέο java object
            Gson gson = new Gson();
          //μετατρέπουμε το Json σε Java Object
            return gson.fromJson(json, Hourly.class);
        }catch(Exception exception){
            throw new Internal(exception.getMessage(),exception.getCause());
        }
    }

    
    public static Daily getDailyWeatherInfo(String latitude, String longitude, Units metricUnit) throws Internal {
        try {
            String excludedCategories = INITIAL_EXCLUDED_CATEGORIES + "," + "hourly" + "," + "current";
            String json = callWeatherApi(latitude, longitude, metricUnit, excludedCategories);
            //δημιουργούμε νέο java object
            Gson gson = new Gson();
            //μετατρέπουμε το Json σε Java Object
            return gson.fromJson(json, Daily.class);
        } catch (Exception exception) {
            throw new Internal(exception.getMessage(), exception.getCause());
        }
    }
    
    
    public static Current getCurrentWeatherInfo(String latitude, String longitude, Units metricUnit) throws Internal {
        try {
            String excludedCategories = INITIAL_EXCLUDED_CATEGORIES + "," + "hourly" + "," + "daily";
            String json = callWeatherApi(latitude, longitude, metricUnit, excludedCategories);
            //δημιουργούμε νέο java object
            Gson gson = new Gson();
            //μετατρέπουμε το Json σε Java Object
            return gson.fromJson(json, Current.class);
        } catch (Exception exception) {
            throw new Internal(exception.getMessage(), exception.getCause());
        }
    }

    
    private static String callWeatherApi(String latitude, String longitude, Units metricUnit, String excludedCategories) throws URISyntaxException, IOException {
        HttpGet request = new HttpGet(WEATHER_API_URI);
        URI uri = new URIBuilder(request.getURI())
                .addParameter("lat", latitude)
                .addParameter("lon", longitude)
                .addParameter("exclude", excludedCategories)
                .addParameter("units", metricUnit.getKey())  //παίρνει τιμή από την μέθοδο getKey της κλάσης Units
                .addParameter("appid", API_KEY)
                .build();
        request.setURI(uri);
        return ApiCall.callApi(request);
    }
        

    public static CityNames getCityNamesLatLon(String citycountry) throws Internal {
    	 try {
             String json = callCityNamesApi(citycountry);
             Gson gson = new Gson();
             //λίστα από object
             //De-serialization 
             //παίρνουμε τον τύπο του collection
             Type founderListType = new TypeToken<ArrayList<CityNames>>(){}.getType();
             List<CityNames> founderList = gson.fromJson(json, founderListType);
             return founderList.get(0); //επιστρέφει την πρώτη λίστα
         } catch (Exception exception) {
             throw new Internal(exception.getMessage(), exception.getCause());
         }
     } 
    
    
    private static String callCityNamesApi(String citycountry) throws URISyntaxException, IOException {
    	HttpGet request = new HttpGet(CITYNAMES_API_URI);
    	URI uri = new URIBuilder(request.getURI())
                .addParameter("q", citycountry)
                .addParameter("appid", API_KEY)
                .build();
        request.setURI(uri);
        return ApiCall.callApi(request);
    }
    
    
    private static String getRemoteExternalIP() throws IOException {
    	//Χρησιμοποιούμε το checkip Amazon Web Service για να βρούμε την ip
        HttpGet request = new HttpGet("http://checkip.amazonaws.com/");
        String remoteIpAddress = ApiCall.callApi(request);
        //Μέθοδος για να αφαιρέσουμε whitespaces κενά και μας επιστρέφει την ip μας
        return remoteIpAddress.replaceAll("\n", "");
    }

    private static LatLon getGeoApiLocationInfo(String ip) throws IOException, URISyntaxException {
        HttpGet request = new HttpGet("http://api.ipstack.com/".concat(ip));
        URI uri = new URIBuilder(request.getURI())
                .addParameter("access_key", GEO_API_KEY)
                .build();
        request.setURI(uri);
        String json = ApiCall.callApi(request);
        JsonObject convertedObject = new Gson().fromJson(json, JsonObject.class);
        //μας επιστρέφει τα lat και τα lon του location μας
        //getAsFloat είναι μέθοδος της κλάσης JsonElement του Gson της Google, και παίρνει το element σαν primitive float value
        return new LatLon(convertedObject.get("longitude").getAsFloat(),convertedObject.get("latitude").getAsFloat());
    }

    public static LatLon getGeolocationInfo() throws Internal {
        try {
            String remoteExternalIp = getRemoteExternalIP();
            return getGeoApiLocationInfo(remoteExternalIp); // ip = η ip του user
        }catch (Exception exception){
            throw new Internal(exception.getMessage(),exception.getCause());
        }
    }
}
