package weather.api.client;

import java.util.List;

public class DailyDet {

    private Long dt;
    private DailyTemp temp;
    private float humidity;
    private float dew_point;
    private float wind_speed;
    private float wind_deg;
    private List<Weather> weather;


    public Long getDt() {
        return dt;
    }

    public void setDt(Long dt) {
        this.dt = dt;
    }

    public DailyTemp getTemp() {
        return temp;
    }

    public void setTemp(DailyTemp temp) {
        this.temp = temp;
    }

    public float getHumidity() {
        return humidity;
    }

    public void setHumidity(float humidity) {
        this.humidity = humidity;
    }

    public float getDew_point() {
        return dew_point;
    }

    public void setDew_point(float dew_point) {
        this.dew_point = dew_point;
    }

    public float getWind_speed() {
        return wind_speed;
    }

    public void setWind_speed(float wind_speed) {
        this.wind_speed = wind_speed;
    }

    public float getWind_deg() {
        return wind_deg;
    }

    public void setWind_deg(float wind_deg) {
        this.wind_deg = wind_deg;
    }

    public List<Weather> getWeather() {
        return weather;
    }

    public void setWeather(List<Weather> weather) {
        this.weather = weather;
    }
    
	@Override
	public String toString() {
		return "\ndt=" + dt + "\ntemp=" + temp + "\nhumidity=" + humidity + "\ndew_point=" + dew_point
				+ "\nwind_speed=" + wind_speed + "\nwind_deg=" + wind_deg + "\nweather=" + weather;
	}
}
