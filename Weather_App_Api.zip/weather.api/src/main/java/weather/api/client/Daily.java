package weather.api.client;

import java.util.List;

public class Daily {

    private String lat;
    private String lon;
    private String timezone;
    private List<DailyDet> daily;

    
    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {  //constructor με παράμετρο
        this.lat = lat;
    }

    public String getLon() {
        return lon;
    }

    public void setLon(String lon) {  //constructor με παράμετρο
        this.lon = lon;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {  //constructor με παράμετρο
        this.timezone = timezone;
    }

    public List<DailyDet> getDaily() {
        return daily;
    }

    public void setDaily(List<DailyDet> daily) {  //constructor με παράμετρο
        this.daily = daily;
    }

	@Override
	public String toString() {
		return "\nlat=" + lat + "\nlon=" + lon + "\ntimezone=" + timezone + "\n" + daily;
	}
}
