package weather.api.client;

import java.util.List;

public class Hourly {

    private String lat;
    private String lon;
    private String timezone;
    private List<HourlyDet> hourly;

    
    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLot() {
        return lon;
    }

    public void setLot(String lot) {
        this.lon = lot;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public List<HourlyDet> getHourly() {
        return hourly;
    }

    public void setHourly(List<HourlyDet> hourly) {
        this.hourly = hourly;
    }

	@Override
	public String toString() {
		return "\nlat=" + lat + "\nlon=" + lon + "\ntimezone=" + timezone + "\n" + hourly;
	}
}
